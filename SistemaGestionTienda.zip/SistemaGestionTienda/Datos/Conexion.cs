﻿
using System.Configuration;
using Microsoft.Data.SqlClient;

namespace SistemaGestionTienda.Datos
{
    public class Conexion
    {
        private readonly string cadenaConexion;

        public Conexion()
        {
            cadenaConexion = ConfigurationManager
                .ConnectionStrings["conexionBD"]
                .ConnectionString;
        }

        public SqlConnection ObtenerConexion()
        {
            return new SqlConnection(cadenaConexion);
        }
    }
}
