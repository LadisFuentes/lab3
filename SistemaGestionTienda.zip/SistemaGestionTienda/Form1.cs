﻿using SistemaGestionTienda.Datos;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SistemaGestionTienda
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            try
            {
                Conexion conexion = new Conexion();

                using (var cn = conexion.ObtenerConexion())
                {
                    cn.Open();
                    MessageBox.Show("¡Conexión exitosa con TiendaElectronica!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error de conexión: " + ex.Message);
            }
        }
    }
}
