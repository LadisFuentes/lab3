﻿
using System.Security.Cryptography;
using System.Text;

namespace SistemaGestionTienda.Servicios
{
    public class SeguridadService
    {
        public static string CalcularHash(string contraseña)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] datos = Encoding.UTF8.GetBytes(contraseña);
                byte[] hash = sha256.ComputeHash(datos);

                StringBuilder resultado = new StringBuilder();

                foreach (byte b in hash)
                {
                    resultado.Append(b.ToString("x2"));
                }

                return resultado.ToString();
            }
        }

        public static bool VerificarContraseña(
            string contraseña,
            string hashGuardado)
        {
            string hashCalculado = CalcularHash(contraseña);

            return hashCalculado == hashGuardado;
        }
    }
}
