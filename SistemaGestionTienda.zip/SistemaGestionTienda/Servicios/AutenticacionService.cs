﻿
using SistemaGestionTienda.Modelos;
using SistemaGestionTienda.Repositorios;

namespace SistemaGestionTienda.Servicios
{
    public class AutenticacionService
    {
        private readonly UsuarioRepositorio repositorio;

        public AutenticacionService()
        {
            repositorio = new UsuarioRepositorio();
        }

        public Usuario IniciarSesion(string nombreUsuario, string contraseña)
        {
            Usuario usuario = repositorio.ObtenerPorUsuario(nombreUsuario);

            if (usuario == null)
                return null;

            bool valido = SeguridadService.VerificarContraseña(
                contraseña,
                usuario.ClaveHash
            );

            if (!valido)
                return null;

            return usuario;
        }
    }
}
