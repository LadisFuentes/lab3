﻿
using System;
using System.Drawing;
using System.Windows.Forms;
using System.Linq;
using SistemaGestionTienda.Repositorios;

namespace SistemaGestionTienda.Formularios
{
    public partial class FrmProductosVendidos : Form
    {
        private DataGridView dgvReporte;
        private Label lblTotalGeneral;

        public FrmProductosVendidos()
        {
            ConfigurarFormulario();
            CrearControles();
            CargarReporte();
        }

        private void ConfigurarFormulario()
        {
            this.Text = "Reporte de Productos Vendidos";
            this.StartPosition = FormStartPosition.CenterParent;
            this.Size = new Size(850, 500);
            this.MinimumSize = new Size(700, 400);
        }

        private void CrearControles()
        {
            Label lblTitulo = new Label();
            lblTitulo.Text = "REPORTE DE PRODUCTOS VENDIDOS";
            lblTitulo.Font = new Font("Arial", 16, FontStyle.Bold);
            lblTitulo.AutoSize = true;
            lblTitulo.Location = new Point(20, 20);

            dgvReporte = new DataGridView();
            dgvReporte.Location = new Point(20, 80);
            dgvReporte.Size = new Size(790, 300);
            dgvReporte.ReadOnly = true;
            dgvReporte.AllowUserToAddRows = false;
            dgvReporte.AutoSizeColumnsMode =
                DataGridViewAutoSizeColumnsMode.Fill;
            dgvReporte.SelectionMode =
                DataGridViewSelectionMode.FullRowSelect;

            lblTotalGeneral = new Label();
            lblTotalGeneral.Font = new Font("Arial", 12, FontStyle.Bold);
            lblTotalGeneral.AutoSize = true;
            lblTotalGeneral.Location = new Point(20, 400);

            this.Controls.Add(lblTitulo);
            this.Controls.Add(dgvReporte);
            this.Controls.Add(lblTotalGeneral);
        }

        private void CargarReporte()
        {
            try
            {
                ReporteRepositorio repositorio =
                    new ReporteRepositorio();

                var datos = repositorio.ObtenerProductosVendidos();

                dgvReporte.DataSource = datos;

                decimal total = datos.Sum(
                    p => p.MontoAcumulado
                );

                lblTotalGeneral.Text =
                    "TOTAL GENERAL: $" + total.ToString("N2");
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Error al cargar el reporte: " + ex.Message,
                    "Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
            }
        }
    }
}
