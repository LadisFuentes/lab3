﻿
using System;
using System.Drawing;
using System.Windows.Forms;

namespace SistemaGestionTienda.Formularios
{
    public class FrmPrincipal : Form
    {
        private MenuStrip menuPrincipal;
        private ToolStripMenuItem menuInventario;
        private ToolStripMenuItem menuReportes;
        private ToolStripMenuItem menuSalir;

        public FrmPrincipal()
        {
            ConfigurarFormulario();
            CrearMenu();
        }

        private void ConfigurarFormulario()
        {
            this.Text = "Sistema de Gestión - Tienda Electrónica";
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Size = new Size(1000, 600);
            this.MinimumSize = new Size(800, 500);
            this.BackColor = Color.WhiteSmoke;
        }

        private void CrearMenu()
        {
            menuPrincipal = new MenuStrip();

            menuInventario = new ToolStripMenuItem("Inventario");
            menuReportes = new ToolStripMenuItem("Reportes");
            menuSalir = new ToolStripMenuItem("Salir");

            // Opciones de inventario
            ToolStripMenuItem consultarStock =
                new ToolStripMenuItem("Consultar stock");

            ToolStripMenuItem actualizarProducto =
                new ToolStripMenuItem("Actualizar producto");

            consultarStock.Click += (sender, e) =>
            {
                using (FrmStock formularioStock = new FrmStock())
                {
                    formularioStock.ShowDialog(this);
                }
            };

            actualizarProducto.Click += (sender, e) =>
            {
                using (FrmActualizarProducto formulario =
                    new FrmActualizarProducto())
                {
                    formulario.ShowDialog(this);
                }
            };

            ToolStripMenuItem registrarProducto =
     new ToolStripMenuItem("Registrar producto");

            registrarProducto.Click += (sender, e) =>
            {
                using (FrmRegistrarProducto formulario =
                    new FrmRegistrarProducto())
                {
                    formulario.ShowDialog(this);
                }
            };

            menuInventario.DropDownItems.Add(consultarStock);
            menuInventario.DropDownItems.Add(registrarProducto);
            menuInventario.DropDownItems.Add(actualizarProducto);
            // Opciones de reportes
            ToolStripMenuItem productosVendidos =
                new ToolStripMenuItem("Productos vendidos");

            productosVendidos.Click += (sender, e) =>
            {
                using (FrmProductosVendidos formulario =
                    new FrmProductosVendidos())
                {
                    formulario.ShowDialog(this);
                }
            };

            menuReportes.DropDownItems.Add(productosVendidos);

            // Salir del sistema
            menuSalir.Click += (sender, e) =>
            {
                this.Close();
            };

            // Agregar menús principales
            menuPrincipal.Items.Add(menuInventario);
            menuPrincipal.Items.Add(menuReportes);
            menuPrincipal.Items.Add(menuSalir);

            this.MainMenuStrip = menuPrincipal;
            this.Controls.Add(menuPrincipal);

            // Título de la pantalla principal
            Label lblTitulo = new Label();
            lblTitulo.Text = "SISTEMA DE GESTIÓN DE TIENDA ELECTRÓNICA";
            lblTitulo.Font = new Font("Arial", 20, FontStyle.Bold);
            lblTitulo.AutoSize = true;
            lblTitulo.Location = new Point(130, 150);

            Label lblBienvenida = new Label();
            lblBienvenida.Text = "Bienvenido al sistema";
            lblBienvenida.Font = new Font("Arial", 14);
            lblBienvenida.AutoSize = true;
            lblBienvenida.Location = new Point(365, 220);

            this.Controls.Add(lblTitulo);
            this.Controls.Add(lblBienvenida);
        }
    }
}
