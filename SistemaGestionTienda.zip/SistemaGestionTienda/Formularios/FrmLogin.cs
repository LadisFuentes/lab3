﻿
using System;
using System.Drawing;
using System.Windows.Forms;
using SistemaGestionTienda.Modelos;
using SistemaGestionTienda.Servicios;

namespace SistemaGestionTienda.Formularios
{
    public class FrmLogin : Form
    {
        private readonly AutenticacionService autenticacion;

        private TextBox txtUsuario;
        private TextBox txtClave;
        private Button btnIngresar;

        public FrmLogin()
        {
            autenticacion = new AutenticacionService();

            // Configuración de la ventana.
            this.Text = "Sistema de Gestión de Tienda";
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Size = new Size(420, 300);
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;

            CrearControles();
        }

        private void CrearControles()
        {
            Label lblTitulo = new Label();
            lblTitulo.Text = "INICIO DE SESIÓN";
            lblTitulo.Font = new Font("Arial", 16, FontStyle.Bold);
            lblTitulo.AutoSize = true;
            lblTitulo.Location = new Point(95, 25);

            Label lblUsuario = new Label();
            lblUsuario.Text = "Usuario:";
            lblUsuario.Location = new Point(55, 90);
            lblUsuario.AutoSize = true;

            txtUsuario = new TextBox();
            txtUsuario.Location = new Point(140, 87);
            txtUsuario.Width = 200;

            Label lblClave = new Label();
            lblClave.Text = "Contraseña:";
            lblClave.Location = new Point(55, 130);
            lblClave.AutoSize = true;

            txtClave = new TextBox();
            txtClave.Location = new Point(140, 127);
            txtClave.Width = 200;
            txtClave.UseSystemPasswordChar = true;

            btnIngresar = new Button();
            btnIngresar.Text = "Ingresar";
            btnIngresar.Location = new Point(140, 185);
            btnIngresar.Width = 200;
            btnIngresar.Height = 35;

            btnIngresar.Click += BtnIngresar_Click;

            this.Controls.Add(lblTitulo);
            this.Controls.Add(lblUsuario);
            this.Controls.Add(txtUsuario);
            this.Controls.Add(lblClave);
            this.Controls.Add(txtClave);
            this.Controls.Add(btnIngresar);

            this.AcceptButton = btnIngresar;
        }

        private void BtnIngresar_Click(object sender, EventArgs e)
        {
            string usuario = txtUsuario.Text.Trim();
            string clave = txtClave.Text;

            if (string.IsNullOrWhiteSpace(usuario) ||
                string.IsNullOrWhiteSpace(clave))
            {
                MessageBox.Show(
                    "Ingrese el usuario y la contraseña.",
                    "Validación",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning
                );
                return;
            }

            try
            {
                Usuario usuarioAutenticado =
                    autenticacion.IniciarSesion(usuario, clave);

                if (usuarioAutenticado == null)
                {
                    MessageBox.Show(
                        "Usuario o contraseña incorrectos.",
                        "Acceso denegado",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error
                    );
                    return;
                }

                MessageBox.Show(
                    "Bienvenido, " + usuarioAutenticado.Nombre,
                    "Acceso correcto",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information
                );

                // Abrir el formulario principal.
                this.Hide();

                using (FrmPrincipal principal = new FrmPrincipal())
                {
                    principal.ShowDialog();
                }

                // Cerrar el login cuando se cierre el menú principal.
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Error al iniciar sesión: " + ex.Message,
                    "Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
            }
        }
    }
}
