﻿
using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using RepoDb;
using SistemaGestionTienda.Datos;
using SistemaGestionTienda.Modelos;

namespace SistemaGestionTienda.Formularios
{
    public partial class FrmStock : Form
    {
        private DataGridView dgvStock;
        private TextBox txtBuscar;
        private Button btnBuscar;
        private Button btnMostrarTodos;

        public FrmStock()
        {
            GlobalConfiguration
                .Setup()
                .UseSqlServer();

            ConfigurarFormulario();
            CrearControles();
            CargarStock();
        }

        private void ConfigurarFormulario()
        {
            this.Text = "Consulta de Inventario";
            this.StartPosition = FormStartPosition.CenterParent;
            this.Size = new Size(850, 500);
            this.MinimumSize = new Size(700, 400);
            this.BackColor = Color.WhiteSmoke;
        }

        private void CrearControles()
        {
            Label lblTitulo = new Label();
            lblTitulo.Text = "INVENTARIO DE PRODUCTOS";
            lblTitulo.Font = new Font("Arial", 16, FontStyle.Bold);
            lblTitulo.AutoSize = true;
            lblTitulo.Location = new Point(20, 20);

            Label lblBuscar = new Label();
            lblBuscar.Text = "Buscar producto:";
            lblBuscar.Location = new Point(20, 75);
            lblBuscar.AutoSize = true;

            txtBuscar = new TextBox();
            txtBuscar.Location = new Point(130, 72);
            txtBuscar.Width = 250;

            btnBuscar = new Button();
            btnBuscar.Text = "Buscar";
            btnBuscar.Location = new Point(400, 70);
            btnBuscar.Width = 100;
            btnBuscar.Click += BtnBuscar_Click;

            btnMostrarTodos = new Button();
            btnMostrarTodos.Text = "Mostrar todos";
            btnMostrarTodos.Location = new Point(510, 70);
            btnMostrarTodos.Width = 120;
            btnMostrarTodos.Click += (s, e) =>
            {
                txtBuscar.Clear();
                CargarStock();
            };

            dgvStock = new DataGridView();
            dgvStock.Location = new Point(20, 120);
            dgvStock.Size = new Size(790, 310);
            dgvStock.ReadOnly = true;
            dgvStock.AllowUserToAddRows = false;
            dgvStock.AutoSizeColumnsMode =
                DataGridViewAutoSizeColumnsMode.Fill;
            dgvStock.SelectionMode =
                DataGridViewSelectionMode.FullRowSelect;
            dgvStock.MultiSelect = false;
            dgvStock.RowHeadersVisible = false;

            this.Controls.Add(lblTitulo);
            this.Controls.Add(lblBuscar);
            this.Controls.Add(txtBuscar);
            this.Controls.Add(btnBuscar);
            this.Controls.Add(btnMostrarTodos);
            this.Controls.Add(dgvStock);
        }

        private void CargarStock(string nombre = "")
        {
            try
            {
                using (var conexion =
                    new Conexion().ObtenerConexion())
                {
                    var productos =
                        conexion.QueryAll<Producto>().ToList();

                    if (!string.IsNullOrWhiteSpace(nombre))
                    {
                        productos = productos
                            .Where(p =>
                                p.Nombre != null &&
                                p.Nombre.IndexOf(
                                    nombre,
                                    StringComparison.OrdinalIgnoreCase
                                ) >= 0)
                            .ToList();
                    }

                    dgvStock.DataSource = productos;

                    AplicarSemaforoStock();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Error al consultar el inventario: " + ex.Message,
                    "Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
            }
        }

        private void BtnBuscar_Click(object sender, EventArgs e)
        {
            CargarStock(txtBuscar.Text.Trim());
        }

        private void AplicarSemaforoStock()
        {
            foreach (DataGridViewRow fila in dgvStock.Rows)
            {
                if (fila.Cells["Stock"].Value != null)
                {
                    int existencia =
                        Convert.ToInt32(fila.Cells["Stock"].Value);

                    if (existencia <= 5)
                    {
                        fila.DefaultCellStyle.BackColor =
                            Color.LightCoral;

                        fila.DefaultCellStyle.ForeColor =
                            Color.DarkRed;
                    }
                }
            }
        }
    }
}
