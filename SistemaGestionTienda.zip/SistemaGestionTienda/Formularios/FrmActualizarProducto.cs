﻿
using System;
using System.Drawing;
using System.Windows.Forms;
using SistemaGestionTienda.Modelos;
using SistemaGestionTienda.Repositorios;

namespace SistemaGestionTienda.Formularios
{
    public partial class FrmActualizarProducto : Form
    {
        private TextBox txtId;
        private TextBox txtNombre;
        private TextBox txtDescripcion;
        private TextBox txtPrecio;
        private TextBox txtStock;

        private Button btnBuscar;
        private Button btnActualizar;
        private Button btnLimpiar;

        private ProductoRepositorio repositorio;
        private Producto productoActual;

        public FrmActualizarProducto()
        {
            repositorio = new ProductoRepositorio();

            ConfigurarFormulario();
            CrearControles();
        }

        private void ConfigurarFormulario()
        {
            Text = "Actualizar productos";
            StartPosition = FormStartPosition.CenterParent;
            Size = new Size(550, 500);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            BackColor = Color.WhiteSmoke;
        }

        private void CrearControles()
        {
            Label titulo = new Label();
            titulo.Text = "ACTUALIZAR PRODUCTO";
            titulo.Font = new Font("Arial", 16, FontStyle.Bold);
            titulo.AutoSize = true;
            titulo.Location = new Point(110, 20);

            CrearEtiqueta("ID del producto:", 45, 90);
            txtId = CrearCampo(190, 87, 150);

            btnBuscar = new Button();
            btnBuscar.Text = "Buscar";
            btnBuscar.Location = new Point(355, 85);
            btnBuscar.Click += BtnBuscar_Click;

            CrearEtiqueta("Nombre:", 45, 145);
            txtNombre = CrearCampo(190, 142, 280);

            CrearEtiqueta("Descripción:", 45, 195);
            txtDescripcion = CrearCampo(190, 192, 280);

            CrearEtiqueta("Precio:", 45, 245);
            txtPrecio = CrearCampo(190, 242, 280);

            CrearEtiqueta("Stock:", 45, 295);
            txtStock = CrearCampo(190, 292, 280);

            btnActualizar = new Button();
            btnActualizar.Text = "Guardar cambios";
            btnActualizar.Location = new Point(190, 365);
            btnActualizar.Size = new Size(140, 40);
            btnActualizar.Click += BtnActualizar_Click;

            btnLimpiar = new Button();
            btnLimpiar.Text = "Limpiar";
            btnLimpiar.Location = new Point(345, 365);
            btnLimpiar.Size = new Size(100, 40);
            btnLimpiar.Click += (s, e) => Limpiar();

            Controls.Add(titulo);
            Controls.Add(btnBuscar);
            Controls.Add(btnActualizar);
            Controls.Add(btnLimpiar);
        }

        private void CrearEtiqueta(string texto, int x, int y)
        {
            Label etiqueta = new Label();
            etiqueta.Text = texto;
            etiqueta.Location = new Point(x, y);
            etiqueta.AutoSize = true;
            Controls.Add(etiqueta);
        }

        private TextBox CrearCampo(int x, int y, int ancho)
        {
            TextBox campo = new TextBox();
            campo.Location = new Point(x, y);
            campo.Width = ancho;
            Controls.Add(campo);
            return campo;
        }

        private void BtnBuscar_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(txtId.Text.Trim(), out int id) || id <= 0)
            {
                MessageBox.Show("Ingrese un ID válido.");
                return;
            }

            try
            {
                productoActual = repositorio.ObtenerPorId(id);

                if (productoActual == null)
                {
                    MessageBox.Show("No se encontró el producto.");
                    return;
                }

                txtNombre.Text = productoActual.Nombre;
                txtDescripcion.Text = productoActual.Descripcion;
                txtPrecio.Text = productoActual.Precio.ToString();
                txtStock.Text = productoActual.Stock.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al buscar: " + ex.Message);
            }
        }

        private void BtnActualizar_Click(object sender, EventArgs e)
        {
            if (productoActual == null)
            {
                MessageBox.Show("Primero busque un producto.");
                return;
            }

            if (string.IsNullOrWhiteSpace(txtNombre.Text))
            {
                MessageBox.Show("Ingrese el nombre del producto.");
                return;
            }

            if (!decimal.TryParse(txtPrecio.Text.Trim(), out decimal precio)
                || precio < 0)
            {
                MessageBox.Show("Ingrese un precio válido.");
                return;
            }

            if (!int.TryParse(txtStock.Text.Trim(), out int stock)
                || stock < 0)
            {
                MessageBox.Show("Ingrese un stock válido.");
                return;
            }

            try
            {
                productoActual.Nombre = txtNombre.Text.Trim();
                productoActual.Descripcion = txtDescripcion.Text.Trim();
                productoActual.Precio = precio;
                productoActual.Stock = stock;

                repositorio.Actualizar(productoActual);

                MessageBox.Show(
                    "Producto actualizado correctamente.",
                    "Actualización",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information
                );
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al actualizar: " + ex.Message);
            }
        }

        private void Limpiar()
        {
            txtId.Clear();
            txtNombre.Clear();
            txtDescripcion.Clear();
            txtPrecio.Clear();
            txtStock.Clear();
            productoActual = null;
        }
    }
}
