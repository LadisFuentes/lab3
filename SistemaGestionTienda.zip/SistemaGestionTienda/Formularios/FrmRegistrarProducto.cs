﻿
using System;
using System.Drawing;
using System.Windows.Forms;
using SistemaGestionTienda.Modelos;
using SistemaGestionTienda.Repositorios;

namespace SistemaGestionTienda.Formularios
{
    public partial class FrmRegistrarProducto : Form
    {
        private TextBox txtNombre;
        private TextBox txtDescripcion;
        private TextBox txtPrecio;
        private TextBox txtStock;

        private ProductoRepositorio repositorio;

        public FrmRegistrarProducto()
        {
            repositorio = new ProductoRepositorio();

            ConfigurarFormulario();
            CrearControles();
        }

        private void ConfigurarFormulario()
        {
            Text = "Registrar producto";
            StartPosition = FormStartPosition.CenterParent;
            Size = new Size(550, 470);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            BackColor = Color.WhiteSmoke;
        }

        private void CrearControles()
        {
            Label titulo = new Label();
            titulo.Text = "REGISTRAR NUEVO PRODUCTO";
            titulo.Font = new Font("Arial", 16, FontStyle.Bold);
            titulo.AutoSize = true;
            titulo.Location = new Point(75, 25);

            CrearEtiqueta("Nombre:", 45, 105);
            txtNombre = CrearCampo(190, 102);

            CrearEtiqueta("Descripción:", 45, 160);
            txtDescripcion = CrearCampo(190, 157);

            CrearEtiqueta("Precio:", 45, 215);
            txtPrecio = CrearCampo(190, 212);

            CrearEtiqueta("Stock inicial:", 45, 270);
            txtStock = CrearCampo(190, 267);

            Button btnGuardar = new Button();
            btnGuardar.Text = "Registrar producto";
            btnGuardar.Location = new Point(190, 335);
            btnGuardar.Size = new Size(170, 40);
            btnGuardar.Click += BtnGuardar_Click;

            Button btnLimpiar = new Button();
            btnLimpiar.Text = "Limpiar";
            btnLimpiar.Location = new Point(370, 335);
            btnLimpiar.Size = new Size(100, 40);
            btnLimpiar.Click += (s, e) => Limpiar();

            Controls.Add(titulo);
            Controls.Add(btnGuardar);
            Controls.Add(btnLimpiar);
        }

        private void CrearEtiqueta(string texto, int x, int y)
        {
            Label etiqueta = new Label();
            etiqueta.Text = texto;
            etiqueta.Location = new Point(x, y);
            etiqueta.AutoSize = true;
            Controls.Add(etiqueta);
        }

        private TextBox CrearCampo(int x, int y)
        {
            TextBox campo = new TextBox();
            campo.Location = new Point(x, y);
            campo.Width = 280;
            Controls.Add(campo);
            return campo;
        }

        private void BtnGuardar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtNombre.Text))
            {
                MessageBox.Show("Ingrese el nombre del producto.");
                return;
            }

            if (!decimal.TryParse(txtPrecio.Text.Trim(), out decimal precio)
                || precio < 0)
            {
                MessageBox.Show("Ingrese un precio válido.");
                return;
            }

            if (!int.TryParse(txtStock.Text.Trim(), out int stock)
                || stock < 0)
            {
                MessageBox.Show("Ingrese un stock válido.");
                return;
            }

            try
            {
                Producto nuevoProducto = new Producto
                {
                    Nombre = txtNombre.Text.Trim(),
                    Descripcion = txtDescripcion.Text.Trim(),
                    Precio = precio,
                    Stock = stock
                };

                repositorio.Agregar(nuevoProducto);

                MessageBox.Show(
                    "Producto registrado correctamente.",
                    "Registro exitoso",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information
                );

                Limpiar();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Error al registrar el producto: " + ex.Message,
                    "Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
            }
        }

        private void Limpiar()
        {
            txtNombre.Clear();
            txtDescripcion.Clear();
            txtPrecio.Clear();
            txtStock.Clear();
            txtNombre.Focus();
        }
    }
}
