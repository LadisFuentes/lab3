﻿
using RepoDb.Attributes;

namespace SistemaGestionTienda.Modelos
{
    // Indica a RepoDb que la tabla se llama Usuarios.
    [Map("Usuarios")]
    public class Usuario
    {
        public int IdUsuario { get; set; }

        public string Nombre { get; set; }

        // Relaciona UsuarioLogin con la columna Usuario.
        [Map("Usuario")]
        public string UsuarioLogin { get; set; }

        public string ClaveHash { get; set; }

        public string Rol { get; set; }
    }
}
