﻿
using RepoDb.Attributes;

namespace SistemaGestionTienda.Modelos
{
    [Map("Productos")]
    public class Producto
    {
        [Primary]
        [Map("producto_id")]
        public int ProductoId { get; set; }

        public string Nombre { get; set; }

        public string Descripcion { get; set; }

        public decimal Precio { get; set; }

        public int Stock { get; set; }
    }
}
