﻿
using System.Collections.Generic;

namespace SistemaGestionTienda.Repositorios
{
    public interface IRepository<T> where T : class
    {
        IEnumerable<T> ObtenerTodos();

        T ObtenerPorId(int id);

        void Agregar(T entidad);

        void Actualizar(T entidad);
    }
}
