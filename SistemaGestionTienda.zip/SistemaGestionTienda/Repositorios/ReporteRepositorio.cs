﻿
using System.Collections.Generic;
using System.Linq;
using RepoDb;
using Microsoft.Data.SqlClient;
using SistemaGestionTienda.Datos;
using SistemaGestionTienda.Modelos;

namespace SistemaGestionTienda.Repositorios
{
    public class ReporteRepositorio
    {
        public List<ReporteProducto> ObtenerProductosVendidos()
        {
            GlobalConfiguration
                .Setup()
                .UseSqlServer();

            string consulta = @"
                SELECT
                    p.nombre AS Producto,
                    SUM(dv.cantidad) AS CantidadVendida,
                    SUM(dv.cantidad * dv.precio_unitario) AS MontoAcumulado
                FROM DetalleVenta dv
                INNER JOIN Productos p
                    ON dv.producto_id = p.producto_id
                GROUP BY p.nombre
                ORDER BY p.nombre";

            using (SqlConnection conexion =
                new Conexion().ObtenerConexion())
            {
                return conexion.ExecuteQuery<ReporteProducto>(consulta)
                    .ToList();
            }
        }
    }
}

