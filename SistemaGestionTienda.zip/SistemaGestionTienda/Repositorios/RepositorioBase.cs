﻿
using System.Collections.Generic;
using System.Linq;
using RepoDb;
using SistemaGestionTienda.Datos;
using Microsoft.Data.SqlClient;

namespace SistemaGestionTienda.Repositorios
{
    public class RepositorioBase<T> : IRepository<T> where T : class
    {
        public RepositorioBase()
        {
            GlobalConfiguration
                .Setup()
                .UseSqlServer();
        }

        public IEnumerable<T> ObtenerTodos()
        {
            using (var conexion = new Conexion().ObtenerConexion())
            {
                return conexion.QueryAll<T>().ToList();
            }
        }

        public T ObtenerPorId(int id)
        {
            using (var conexion = new Conexion().ObtenerConexion())
            {
                return conexion.Query<T>(id).FirstOrDefault();
            }
        }

        public void Agregar(T entidad)
        {
            using (var conexion = new Conexion().ObtenerConexion())
            {
                conexion.Insert<T>(entidad);
            }
        }

        public void Actualizar(T entidad)
        {
            using (var conexion = new Conexion().ObtenerConexion())
            {
                conexion.Update<T>(entidad);
            }
        }
    }
}
