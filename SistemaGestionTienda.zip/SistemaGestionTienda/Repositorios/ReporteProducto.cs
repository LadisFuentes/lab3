﻿
namespace SistemaGestionTienda.Modelos
{
    public class ReporteProducto
    {
        public string Producto { get; set; }

        public int CantidadVendida { get; set; }

        public decimal MontoAcumulado { get; set; }
    }
}
