﻿
using System.Linq;
using Microsoft.Data.SqlClient;
using RepoDb;
using SistemaGestionTienda.Datos;
using SistemaGestionTienda.Modelos;

namespace SistemaGestionTienda.Repositorios
{
    public class UsuarioRepositorio
    {
        public Usuario ObtenerPorUsuario(string nombreUsuario)
        {
            GlobalConfiguration
                .Setup()
                .UseSqlServer();

            using (SqlConnection conexion =
                new Conexion().ObtenerConexion())
            {
                return conexion.Query<Usuario>(
                    u => u.UsuarioLogin == nombreUsuario
                ).FirstOrDefault();
            }
        }
    }
}
