﻿
using SistemaGestionTienda.Modelos;

namespace SistemaGestionTienda.Repositorios
{
    public class ProductoRepositorio : RepositorioBase<Producto>
    {
    }
}
