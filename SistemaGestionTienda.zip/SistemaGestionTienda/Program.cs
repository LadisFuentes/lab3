﻿
using System;
using System.Windows.Forms;
using SistemaGestionTienda.Servicios;

namespace SistemaGestionTienda
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            string hash = SeguridadService.CalcularHash("Tienda2026");

            MessageBox.Show(
                hash,
                "Hash SHA-256 de prueba"
            );

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            Application.Run(
                new SistemaGestionTienda.Formularios.FrmLogin()
            );
        }
    }
}
